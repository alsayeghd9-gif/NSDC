'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'

type NavItem = { href: string; emoji: string; labelAr: string }

const items: NavItem[] = [
  { href: '/dashboard',           emoji: '🏠', labelAr: 'الرئيسية'  },
  { href: '/challenges',          emoji: '🏆', labelAr: 'التحديات'  },
  { href: '/leaderboard',         emoji: '📊', labelAr: 'المتصدرون' },
  { href: '/journey',             emoji: '👤', labelAr: 'ملفي'      },
]

interface Props {
  theme?: 'light' | 'dark'
}

export default function BottomNav({ theme = 'light' }: Props) {
  const pathname = usePathname()
  const isDark = theme === 'dark'

  return (
    <nav
      className="flex justify-around items-center pb-2 flex-shrink-0"
      style={{
        height: 74,
        background:  isDark ? '#1E1E1E' : 'white',
        borderTop:   isDark ? '1px solid #252525' : '1.5px solid #F5EFE6',
      }}
    >
      {items.map((item) => {
        const active = pathname === item.href || (item.href === '/journey' && pathname.startsWith('/journey'))
        return (
          <Link key={item.href} href={item.href} className="text-center flex-1 flex flex-col items-center">
            {active ? (
              <>
                <span
                  className="w-[30px] h-[30px] rounded-[10px] flex items-center justify-center text-base mx-auto mb-[3px]"
                  style={{
                    background:  '#FFD166',
                    boxShadow:   '0 2px 8px rgba(255,183,0,0.3)',
                    fontSize:    16,
                  }}
                >
                  {item.emoji}
                </span>
                <span className="text-[9px] font-extrabold" style={{ color: '#CC9000' }}>
                  {item.labelAr}
                </span>
              </>
            ) : (
              <span style={{ opacity: isDark ? 0.34 : 0.36 }} className="flex flex-col items-center">
                <span className="text-[22px] mb-[3px] block">{item.emoji}</span>
                <span className="text-[9px]" style={{ color: isDark ? '#555' : '#888' }}>
                  {item.labelAr}
                </span>
              </span>
            )}
          </Link>
        )
      })}
    </nav>
  )
}
