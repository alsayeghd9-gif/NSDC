interface Props {
  width?: number
  height?: number
  className?: string
}

export default function MascotIcon({ width = 56, height = 67, className }: Props) {
  const vw = 74
  const vh = 88
  return (
    <svg
      width={width}
      height={height}
      viewBox={`0 0 ${vw} ${vh}`}
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      style={{ filter: 'drop-shadow(0 6px 14px rgba(180,110,0,0.22))' }}
    >
      <path d="M37 5C37 5 9 46 9 62C9 76.5 21.5 86 37 86C52.5 86 65 76.5 65 62C65 46 37 5 37 5Z" fill="#FFD166" />
      <path d="M25 20C20 33 13 48 12 60" stroke="rgba(255,255,255,0.44)" strokeWidth="6.5" strokeLinecap="round" fill="none" />
      <ellipse cx="15" cy="66" rx="8.5" ry="5.5" fill="#CC8000" opacity=".26" />
      <ellipse cx="59" cy="66" rx="8.5" ry="5.5" fill="#CC8000" opacity=".26" />
      <ellipse cx="27" cy="59" rx="6.5" ry="7.5" fill="#1A1A1A" />
      <ellipse cx="47" cy="59" rx="6.5" ry="7.5" fill="#1A1A1A" />
      <circle cx="29.5" cy="55" r="2.8" fill="white" />
      <circle cx="49.5" cy="55" r="2.8" fill="white" />
      <path d="M24 71Q37 82 50 71" stroke="#1A1A1A" strokeWidth="2.8" strokeLinecap="round" fill="none" />
    </svg>
  )
}
