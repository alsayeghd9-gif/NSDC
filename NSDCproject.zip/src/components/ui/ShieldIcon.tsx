interface Props {
  fill?: string
  locked?: boolean
  starColor?: string
}

export default function ShieldIcon({ fill = '#2E2E2E', locked = false, starColor = 'rgba(255,220,140,.92)' }: Props) {
  return (
    <svg width="30" height="36" viewBox="0 0 50 60" xmlns="http://www.w3.org/2000/svg">
      {!locked && (
        <defs>
          <linearGradient id={`sg-${fill.replace('#', '')}`} x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%"   stopColor="#F0A060" />
            <stop offset="100%" stopColor="#7A3000" />
          </linearGradient>
        </defs>
      )}
      <path
        d="M25 2L3 12V30C3 44 12 54 25 58C38 54 47 44 47 30V12L25 2Z"
        fill={locked ? fill : `url(#sg-${fill.replace('#', '')})`}
      />
      {!locked ? (
        <>
          <path
            d="M25 7L8 16V30C8 42 16 51 25 54C34 51 42 42 42 30V16L25 7Z"
            fill="rgba(255,255,255,0.1)"
          />
          <text x="25" y="37" textAnchor="middle" fontSize="18" fill={starColor}>★</text>
        </>
      ) : (
        <>
          <rect x="18" y="27" width="14" height="12" rx="3" fill={fill === '#2E2E2E' ? '#383838' : '#2B2B2B'} />
          <path
            d="M20 27V22C20 19 30 19 30 22V27"
            stroke={fill === '#2E2E2E' ? '#383838' : '#2B2B2B'}
            strokeWidth="2.5"
            fill="none"
            strokeLinecap="round"
          />
        </>
      )}
    </svg>
  )
}
