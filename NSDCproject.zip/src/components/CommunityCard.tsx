'use client'

import { useState, useEffect, useRef } from 'react'
import Link from 'next/link'
import type { Encouragement } from '@/lib/types'

interface Props {
  messages: Encouragement[]
  intervalMs?: number
}

export default function CommunityCard({ messages, intervalMs = 10000 }: Props) {
  const [index,   setIndex]   = useState(0)
  const [visible, setVisible] = useState(true)
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null)

  useEffect(() => {
    if (messages.length < 2) return

    timerRef.current = setInterval(() => {
      setVisible(false)
      setTimeout(() => {
        setIndex(i => (i + 1) % messages.length)
        setVisible(true)
      }, 500)
    }, intervalMs)

    return () => { if (timerRef.current) clearInterval(timerRef.current) }
  }, [messages.length, intervalMs])

  if (!messages.length) return null

  const msg = messages[index]

  return (
    <div
      className="mx-[14px] mt-[10px]"
      style={{
        background:   'white',
        borderRadius: 18,
        padding:      '14px 16px',
        boxShadow:    '0 2px 12px rgba(0,0,0,0.06)',
        position:     'relative',
        overflow:     'hidden',
      }}
    >
      {/* Yellow accent strip on the RTL-start side */}
      <div
        style={{
          position:     'absolute',
          right:        0, top: 0, bottom: 0,
          width:        3.5,
          background:   'linear-gradient(180deg,#FFD166,#FFA500)',
          borderRadius: '0 18px 18px 0',
        }}
      />

      {/* Header */}
      <div className="flex items-center justify-between mb-[10px] pr-[4px]">
        <div className="flex items-center gap-[6px]">
          <span className="text-[13px]">💬</span>
          <span className="text-[10px] font-bold tracking-[0.03em]" style={{ color: '#C0B5A8' }}>
            من المجتمع · Community
          </span>
        </div>

        {/* Progress dots */}
        <div className="flex gap-[4px] items-center">
          {messages.map((_, i) => (
            <div
              key={i}
              style={{
                width:        i === index ? 18 : 6,
                height:       6,
                borderRadius: 3,
                background:   i === index ? '#FFD166' : 'rgba(200,150,0,0.2)',
                transition:   'all 0.45s ease',
                flexShrink:   0,
              }}
            />
          ))}
        </div>
      </div>

      {/* Rotating message */}
      <div
        className="pr-[4px]"
        style={{ opacity: visible ? 1 : 0, transition: 'opacity 0.5s ease' }}
      >
        <div className="text-[20px] mb-[7px]">{msg.emoji}</div>
        <div
          className="text-[13px] font-semibold leading-[1.68] mb-[10px]"
          style={{ color: '#1A1A1A' }}
        >
          «{msg.text}»
        </div>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-[7px]">
            <span className="text-[11px]" style={{ color: '#AAA' }}>— {msg.authorName}</span>
            {msg.badge && (
              <span
                className="text-[9px] font-bold rounded-[5px] px-[7px] py-[2px]"
                style={{ color: '#06D6A0', background: '#EEF9F4' }}
              >
                {msg.badge}
              </span>
            )}
          </div>
          <Link
            href="/submit-encouragement"
            className="text-[10px] font-semibold whitespace-nowrap"
            style={{ color: '#FFB800' }}
          >
            أضف رسالتك ›
          </Link>
        </div>
      </div>
    </div>
  )
}
