'use client'

import { useEffect } from 'react'
import type { UnlockPayload } from '@/lib/types'

const CONFETTI: { top: string; left: string; w: number; h: number; color: string; radius: string; dur: string; delay: string }[] = [
  { top: '3%',  left: '8%',  w: 8, h: 8, color: '#FFD166', radius: '50%',  dur: '2.1s', delay: '0s'    },
  { top: '5%',  left: '24%', w: 6, h: 7, color: '#06D6A0', radius: '2px',  dur: '2.4s', delay: '0.15s' },
  { top: '2%',  left: '42%', w: 9, h: 5, color: '#FF6B6B', radius: '50%',  dur: '1.9s', delay: '0.3s'  },
  { top: '4%',  left: '60%', w: 6, h: 8, color: '#FFD166', radius: '0',    dur: '2.3s', delay: '0.45s' },
  { top: '6%',  left: '76%', w: 7, h: 6, color: '#C4A8FF', radius: '50%',  dur: '2.0s', delay: '0.6s'  },
  { top: '3%',  left: '88%', w: 5, h: 7, color: '#06D6A0', radius: '2px',  dur: '2.5s', delay: '0.75s' },
  { top: '12%', left: '5%',  w: 7, h: 5, color: '#FF6B6B', radius: '50%',  dur: '2.2s', delay: '0.9s'  },
  { top: '10%', left: '92%', w: 8, h: 4, color: '#FFD166', radius: '2px',  dur: '1.8s', delay: '1.05s' },
  { top: '1%',  left: '34%', w: 5, h: 9, color: '#C4A8FF', radius: '50%',  dur: '2.6s', delay: '1.2s'  },
  { top: '7%',  left: '52%', w: 8, h: 6, color: '#FFB84D', radius: '0',    dur: '2.1s', delay: '1.35s' },
  { top: '2%',  left: '68%', w: 6, h: 6, color: '#06D6A0', radius: '50%',  dur: '2.3s', delay: '1.5s'  },
  { top: '15%', left: '78%', w: 7, h: 5, color: '#FFD166', radius: '2px',  dur: '2.0s', delay: '0.2s'  },
  { top: '9%',  left: '16%', w: 5, h: 8, color: '#FF6B6B', radius: '50%',  dur: '2.4s', delay: '0.35s' },
  { top: '6%',  left: '30%', w: 9, h: 5, color: '#FFB84D', radius: '0',    dur: '1.9s', delay: '0.5s'  },
  { top: '1%',  left: '48%', w: 6, h: 7, color: '#C4A8FF', radius: '50%',  dur: '2.5s', delay: '0.65s' },
  { top: '11%', left: '84%', w: 8, h: 7, color: '#FFD166', radius: '50%',  dur: '2.0s', delay: '0.95s' },
]

interface Props {
  payload: UnlockPayload
  onClose: () => void
}

export default function UnlockCelebration({ payload, onClose }: Props) {
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose() }
    document.addEventListener('keydown', onKey)
    return () => document.removeEventListener('keydown', onKey)
  }, [onClose])

  return (
    <div
      className="fixed inset-0 z-50 flex flex-col overflow-hidden"
      style={{ background: 'linear-gradient(175deg,#0D0020 0%,#200840 50%,#180630 100%)' }}
      dir="rtl"
    >
      {/* Status bar */}
      <div
        className="flex items-end justify-between px-[22px] pb-[10px] flex-shrink-0"
        style={{ height: 48 }}
      >
        <span className="text-[14px] font-bold" style={{ color: '#333', direction: 'ltr', fontFamily: 'system-ui, sans-serif' }}>
          9:41
        </span>
      </div>

      {/* Confetti layer */}
      <div className="absolute inset-0 pointer-events-none z-[5] overflow-hidden">
        {CONFETTI.map((c, i) => (
          <div
            key={i}
            className="absolute animate-confetti-drop"
            style={{
              top: c.top, left: c.left,
              width: c.w, height: c.h,
              background: c.color,
              borderRadius: c.radius,
              '--dur':   c.dur,
              '--delay': c.delay,
            } as React.CSSProperties}
          />
        ))}
      </div>

      {/* Main celebration content */}
      <div className="relative z-10 flex-1 flex flex-col items-center justify-center px-[26px] pb-[28px] text-center">

        {/* "New badge unlocked" chip */}
        <div
          className="inline-flex items-center gap-[8px] rounded-[14px] px-[18px] py-[7px] mb-[22px] animate-fade-up"
          style={{
            background: 'rgba(255,215,0,0.12)',
            border:     '1px solid rgba(255,215,0,0.24)',
            '--delay':  '0.2s',
          } as React.CSSProperties}
        >
          <span className="text-[16px]">🎊</span>
          <span className="text-[13px] font-bold" style={{ color: '#FFD166' }}>
            تم فتح وسام جديد!
          </span>
        </div>

        {/* Badge icon with glow + pop animation */}
        <div className="mb-[20px] animate-badge-pop">
          <div
            className="w-[118px] h-[118px] rounded-[30px] flex items-center justify-center mx-auto animate-glow-pulse"
            style={{ background: 'linear-gradient(145deg,#FFF4CC,#FFD166)' }}
          >
            <span className="text-[56px]">{payload.emoji}</span>
          </div>
        </div>

        {/* Name */}
        <div
          className="text-[30px] font-black text-white mb-[5px] animate-fade-up tracking-[-0.5px]"
          style={{ '--delay': '0.92s' } as React.CSSProperties}
        >
          {payload.nameAr}
        </div>
        <div
          className="text-[12px] font-semibold tracking-[0.05em] mb-[20px] animate-fade-up"
          style={{ color: 'rgba(255,255,255,0.38)', '--delay': '1.02s' } as React.CSSProperties}
        >
          {payload.nameEn}
        </div>

        {/* Message card */}
        <div
          className="rounded-[20px] px-[20px] py-[16px] mb-[16px] max-w-[280px] animate-fade-up"
          style={{
            background: 'rgba(255,255,255,0.07)',
            border:     '1px solid rgba(255,255,255,0.1)',
            '--delay':  '1.12s',
          } as React.CSSProperties}
        >
          <p className="text-[14px] leading-[1.75]" style={{ color: 'rgba(255,255,255,0.72)' }}>
            {payload.message}
          </p>
        </div>

        {/* Date */}
        <div
          className="text-[11px] mb-[26px] animate-fade-up"
          style={{ color: '#3A3A3A', '--delay': '1.22s' } as React.CSSProperties}
        >
          تم فتحه: {payload.unlockedAt}
        </div>

        {/* Continue button */}
        <button
          onClick={onClose}
          className="rounded-[18px] px-[52px] py-[16px] cursor-pointer animate-fade-up"
          style={{
            background: '#FFD166',
            boxShadow:  '0 8px 28px rgba(255,200,0,0.24)',
            '--delay':  '1.36s',
          } as React.CSSProperties}
        >
          <div className="text-[18px] font-black" style={{ color: '#1A1A1A' }}>متابعة</div>
          <div className="text-[10px]" style={{ color: 'rgba(0,0,0,0.45)' }}>Continue</div>
        </button>
      </div>
    </div>
  )
}
