'use client'

import { useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { useAuth } from '@/context/AuthContext'
import MascotIcon from '@/components/ui/MascotIcon'

interface Props {
  children: React.ReactNode
  /** Restrict this route to founder/admin roles. */
  requireAdmin?: boolean
}

/**
 * Client-side route protection:
 *  - not signed in            → / (sign-in)
 *  - signed in, pending       → /pending
 *  - admin route, member role → /dashboard
 */
export default function AuthGuard({ children, requireAdmin = false }: Props) {
  const { user, loading } = useAuth()
  const router = useRouter()

  const isAdmin = user?.role === 'admin' || user?.role === 'founder'

  useEffect(() => {
    if (loading) return
    if (!user) {
      router.replace('/')
    } else if (user.status !== 'approved') {
      router.replace('/pending')
    } else if (requireAdmin && !isAdmin) {
      router.replace('/dashboard')
    }
  }, [user, loading, requireAdmin, isAdmin, router])

  if (loading || !user || user.status !== 'approved' || (requireAdmin && !isAdmin)) {
    return (
      <div
        className="min-h-screen flex flex-col items-center justify-center gap-4"
        style={{ background: '#FFF9F0' }}
      >
        <MascotIcon width={64} height={76} />
        <p className="text-[13px] font-semibold" style={{ color: '#9A7020' }}>
          لحظة من فضلك...
        </p>
      </div>
    )
  }

  return <>{children}</>
}
