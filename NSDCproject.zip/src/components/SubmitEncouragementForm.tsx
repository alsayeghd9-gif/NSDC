'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import MascotIcon from '@/components/ui/MascotIcon'

const EMOJIS = ['💛', '🌱', '⭐', '💪', '🌿', '🤝']
const MAX_CHARS = 100

export default function SubmitEncouragementForm({
  userName   = 'أحمد',
  userEmoji  = '👦',
  rankLabel  = '🥉 البرونزي',
}: {
  userName?:  string
  userEmoji?: string
  rankLabel?: string
}) {
  const router = useRouter()
  const [selectedEmoji, setSelectedEmoji] = useState(EMOJIS[0])
  const [text,          setText]          = useState('')
  const [submitted,     setSubmitted]     = useState(false)

  const count = text.length
  const pct   = Math.min(count, MAX_CHARS)

  const barColor =
    count > 90 ? '#FF6B6B' :
    count > 70 ? '#FFB800' :
    '#06D6A0'

  const handleSubmit = () => {
    if (!text.trim() || count > MAX_CHARS) return
    // TODO: write to Firestore encouragements collection with status: 'pending'
    setSubmitted(true)
  }

  if (submitted) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center text-center px-8 gap-4">
        <span className="text-[52px]">📨</span>
        <h2 className="text-[20px] font-black" style={{ color: '#1A1A1A' }}>تم الإرسال!</h2>
        <p className="text-[13px]" style={{ color: '#C0B5A8', lineHeight: 1.8 }}>
          شكراً على رسالتك. ستُراجع من قبل المؤسس قبل النشر.
          <br />
          <span className="text-[11px]">Your message has been submitted for review.</span>
        </p>
        <button
          onClick={() => router.back()}
          className="mt-4 rounded-[16px] px-8 py-3 text-[15px] font-bold text-white"
          style={{ background: 'linear-gradient(145deg,#06D6A0,#04BE8C)' }}
        >
          العودة
        </button>
      </div>
    )
  }

  return (
    <div className="flex-1 overflow-y-auto no-scrollbar" style={{ WebkitOverflowScrolling: 'touch' }}>
      <div className="px-[20px] py-[18px] pb-[32px]">

        {/* Mascot intro */}
        <div className="text-center mb-[18px]">
          <div className="inline-block mb-[7px]">
            <MascotIcon width={52} height={62} />
          </div>
          <p className="text-[15px] font-bold mb-[3px]" style={{ color: '#1A1A1A' }}>
            شجّع زملاءك في النادي! 💛
          </p>
          <p className="text-[11px]" style={{ color: '#C0B5A8' }}>Encourage your fellow members</p>
        </div>

        {/* Sender chip */}
        <div
          className="rounded-[14px] px-[14px] py-[12px] mb-[14px] flex items-center gap-[10px]"
          style={{ background: '#F8F5EF' }}
        >
          <span className="text-[22px]">{userEmoji}</span>
          <div className="flex-1">
            <p className="text-[10px] mb-[2px]" style={{ color: '#C0B5A8' }}>اسمك في الرسالة</p>
            <p className="text-[14px] font-bold" style={{ color: '#1A1A1A' }}>{userName}</p>
          </div>
          <div className="rounded-[7px] px-[9px] py-[3px]" style={{ background: '#EEF9F4' }}>
            <span className="text-[9px] font-bold" style={{ color: '#06D6A0' }}>{rankLabel}</span>
          </div>
        </div>

        {/* Emoji picker */}
        <div className="mb-[14px]">
          <p className="text-[10px] font-bold tracking-[0.04em] mb-[8px]" style={{ color: '#C0B5A8' }}>
            اختر رمزاً واحداً
          </p>
          <div className="flex gap-[7px]">
            {EMOJIS.map(emoji => (
              <button
                key={emoji}
                onClick={() => setSelectedEmoji(emoji)}
                className="w-[40px] h-[40px] rounded-[11px] flex items-center justify-center text-[19px] cursor-pointer transition-opacity"
                style={{
                  background:  selectedEmoji === emoji ? '#FFF9EC' : '#F8F8F8',
                  border:      selectedEmoji === emoji ? '2px solid #FFD166' : '1.5px solid #EDEDED',
                  opacity:     selectedEmoji === emoji ? 1 : 0.65,
                }}
              >
                {emoji}
              </button>
            ))}
          </div>
        </div>

        {/* Textarea */}
        <p className="text-[10px] font-bold tracking-[0.04em] mb-[8px]" style={{ color: '#C0B5A8' }}>
          رسالتك للمجتمع
        </p>
        <textarea
          rows={4}
          placeholder="اكتب رسالة إيجابية ومشجعة..."
          maxLength={MAX_CHARS + 20}
          value={text}
          onChange={e => setText(e.target.value)}
          className="w-full rounded-[14px] px-[14px] py-[13px] text-[14px] font-medium leading-[1.7] resize-none outline-none mb-[7px]"
          style={{
            background:  '#FAFAF8',
            border:      '1.5px solid #E8E0D0',
            color:       '#1A1A1A',
            direction:   'rtl',
            fontFamily:  'var(--font-cairo), Cairo, sans-serif',
          }}
        />

        {/* Character counter */}
        <div className="flex items-center justify-between mb-[5px]">
          <span className="text-[10px]" style={{ color: '#C0B5A8' }}>الحد الأقصى · Max {MAX_CHARS}</span>
          <span className="text-[12px] font-bold" style={{ color: barColor }}>
            {count} / {MAX_CHARS}
          </span>
        </div>
        <div className="h-[4px] rounded-[4px] overflow-hidden mb-[18px]" style={{ background: '#F0EAE0' }}>
          <div
            className="h-full rounded-[4px] transition-all duration-200"
            style={{ width: `${pct}%`, background: barColor }}
          />
        </div>

        {/* Guidelines */}
        <div className="rounded-[14px] px-[16px] py-[14px] mb-[18px]" style={{ background: '#F9F6F0' }}>
          <p className="text-[11px] font-bold mb-[8px]" style={{ color: '#1A1A1A' }}>إرشادات النشر</p>
          <p className="text-[10px] leading-[2.1]" style={{ color: '#999' }}>
            ✓ رسائل إيجابية ومشجعة فقط<br />
            ✓ مناسبة لجميع الأعمار والعائلات<br />
            ✗ لا روابط أو صور أو إعلانات<br />
            ✗ رمز تعبيري واحد فقط كحد أقصى
          </p>
        </div>

        {/* Submit button */}
        <button
          onClick={handleSubmit}
          disabled={!text.trim() || count > MAX_CHARS}
          className="w-full rounded-[16px] py-[16px] text-center cursor-pointer mb-[14px] transition-opacity disabled:opacity-50"
          style={{
            background: 'linear-gradient(145deg,#06D6A0,#04BE8C)',
            boxShadow:  '0 8px 24px rgba(6,214,160,0.36)',
          }}
        >
          <p className="text-[17px] font-black text-white mb-[2px]">إرسال للمراجعة 📨</p>
          <p className="text-[10px]" style={{ color: 'rgba(255,255,255,0.72)' }}>Submit for review</p>
        </button>

        {/* Moderation notice */}
        <p className="text-center text-[11px] leading-[1.65]" style={{ color: '#C0B5A8' }}>
          ستُراجع رسالتك من قبل المؤسس قبل النشر
          <br />
          <span className="text-[10px]" style={{ color: '#D5CFC5' }}>
            Your message will be reviewed before publishing
          </span>
        </p>

      </div>
    </div>
  )
}
