'use client'

import { createContext, useContext, useEffect, useState, useCallback } from 'react'
import { doc, getDoc, setDoc, serverTimestamp } from 'firebase/firestore'
import { db, isFirebaseConfigured } from '@/lib/firebase'
import { useAuth } from '@/context/AuthContext'
import UnlockCelebration from '@/components/UnlockCelebration'
import {
  applyCheckIn, emptyProgress, demoProgress, todayKey, xpThreshold,
  type ProgressState,
} from '@/lib/progress'
import type { UnlockPayload } from '@/lib/types'

const DEMO_PROGRESS_KEY = 'nsdc-demo-progress'

type ProgressContextValue = {
  progress: ProgressState | null
  /** True once today's check-in is recorded. */
  checkedInToday: boolean
  /** XP needed to finish the current level. */
  xpToNext: number
  /** Perform today's check-in. No-op if already done today. */
  checkIn: () => void
}

const ProgressContext = createContext<ProgressContextValue | null>(null)

export function ProgressProvider({ children }: { children: React.ReactNode }) {
  const { user } = useAuth()
  const [progress, setProgress] = useState<ProgressState | null>(null)
  const [queue,    setQueue]    = useState<UnlockPayload[]>([])

  // ── Load progress when a user signs in ──
  useEffect(() => {
    if (!user) {
      setProgress(null)
      setQueue([])
      return
    }

    if (!isFirebaseConfigured) {
      // Demo mode: persist per-uid in localStorage, seeded from the design mocks.
      try {
        const raw = localStorage.getItem(`${DEMO_PROGRESS_KEY}-${user.uid}`)
        setProgress(raw ? (JSON.parse(raw) as ProgressState) : demoProgress())
      } catch {
        setProgress(demoProgress())
      }
      return
    }

    // Real mode: read the progress fields from users/{uid}.
    let cancelled = false
    ;(async () => {
      const snap = await getDoc(doc(db!, 'users', user.uid))
      if (cancelled) return
      const d = snap.data() ?? {}
      setProgress({
        streak:        (d.streak as number) ?? 0,
        bestStreak:    (d.bestStreak as number) ?? 0,
        totalCheckIns: (d.totalCheckIns as number) ?? 0,
        xp:            (d.xp as number) ?? 0,
        level:         (d.level as number) ?? 1,
        coins:         (d.coins as number) ?? 0,
        streakShields: (d.streakShields as number) ?? 0,
        lastCheckIn:   (d.lastCheckIn as string) ?? null,
        badges:        (d.badgeDates as Record<string, string>) ?? {},
      })
    })().catch(() => { if (!cancelled) setProgress(emptyProgress()) })

    return () => { cancelled = true }
  }, [user])

  const persist = useCallback((uid: string, state: ProgressState, xpEarned: number) => {
    if (!isFirebaseConfigured) {
      localStorage.setItem(`${DEMO_PROGRESS_KEY}-${uid}`, JSON.stringify(state))
      return
    }
    const today = todayKey()
    // Check-in record: one doc per member per day → "only once per day" holds
    // even across devices (same deterministic id).
    setDoc(doc(db!, 'checkins', `${uid}_${today}`), {
      uid, date: today, xpEarned, createdAt: serverTimestamp(),
    }).catch(console.error)
    // Progress snapshot on the user doc — all screens read from here.
    setDoc(doc(db!, 'users', uid), {
      streak: state.streak,
      bestStreak: state.bestStreak,
      totalCheckIns: state.totalCheckIns,
      xp: state.xp,
      level: state.level,
      coins: state.coins,
      streakShields: state.streakShields,
      lastCheckIn: state.lastCheckIn,
      badgeDates: state.badges,
      badges: Object.keys(state.badges),
      rank: rankIdFromLevel(state.level),
      updatedAt: serverTimestamp(),
    }, { merge: true }).catch(console.error)
  }, [])

  const checkIn = useCallback(() => {
    if (!user || !progress) return
    const result = applyCheckIn(progress)
    if (result.alreadyCheckedIn) return
    // Optimistic local update → every screen re-renders instantly.
    setProgress(result.state)
    if (result.unlocks.length) setQueue(q => [...q, ...result.unlocks])
    persist(user.uid, result.state, result.xpEarned)
  }, [user, progress, persist])

  const checkedInToday = progress?.lastCheckIn === todayKey()

  return (
    <ProgressContext.Provider
      value={{
        progress,
        checkedInToday,
        xpToNext: xpThreshold(progress?.level ?? 1),
        checkIn,
      }}
    >
      {children}
      {/* Unlock celebrations play sequentially over whatever screen is open */}
      {queue.length > 0 && (
        <UnlockCelebration
          payload={queue[0]}
          onClose={() => setQueue(q => q.slice(1))}
        />
      )}
    </ProgressContext.Provider>
  )
}

function rankIdFromLevel(level: number): string {
  const ids = ['bronze-rookie', 'silver-challenger', 'gold-guardian', 'platinum-elite', 'diamond-legend']
  return ids[Math.min(Math.floor((level - 1) / 10), ids.length - 1)]
}

export function useProgress() {
  const ctx = useContext(ProgressContext)
  if (!ctx) throw new Error('useProgress must be used inside <ProgressProvider>')
  return ctx
}
