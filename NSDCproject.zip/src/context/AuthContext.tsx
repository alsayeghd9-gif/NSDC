'use client'

import { createContext, useContext, useEffect, useState, useCallback } from 'react'
import {
  GoogleAuthProvider,
  signInWithPopup,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  sendPasswordResetEmail,
  signOut,
  onAuthStateChanged,
  type User as FirebaseUser,
} from 'firebase/auth'
import { doc, getDoc, setDoc, serverTimestamp } from 'firebase/firestore'
import { auth, db, isFirebaseConfigured } from '@/lib/firebase'
import { mockUser } from '@/lib/mockData'
import type { UserProfile, UserRole } from '@/lib/types'

const DEMO_SESSION_KEY = 'nsdc-demo-session'

type AuthContextValue = {
  user: UserProfile | null
  loading: boolean
  demoMode: boolean
  signInWithGoogle: () => Promise<void>
  signInWithEmail: (email: string, password: string) => Promise<void>
  signUpWithEmail: (email: string, password: string, displayName: string) => Promise<void>
  resetPassword: (email: string) => Promise<void>
  signOutUser: () => Promise<void>
  /** Demo-mode only: sign in with a chosen role to explore the app. */
  signInDemo: (role: UserRole) => void
}

const AuthContext = createContext<AuthContextValue | null>(null)

function demoProfile(role: UserRole): UserProfile {
  if (role === 'founder' || role === 'admin') {
    return {
      ...mockUser,
      uid: `demo-${role}`,
      displayName: role === 'founder' ? 'المؤسس' : 'المشرف',
      email: `${role}@demo.club`,
      emoji: '🛡️',
      role,
      status: 'approved',
    }
  }
  return { ...mockUser, email: 'ahmed@demo.club' }
}

/** Firestore users/{uid} doc shape → UserProfile, with defaults for new members. */
function profileFromDoc(uid: string, data: Record<string, unknown> | undefined, fb: FirebaseUser): UserProfile {
  return {
    uid,
    displayName:   (data?.displayName as string) ?? fb.displayName ?? 'عضو جديد',
    email:         fb.email ?? undefined,
    emoji:         (data?.emoji as string) ?? '🙂',
    streak:        (data?.streak as number) ?? 0,
    xp:            (data?.xp as number) ?? 0,
    xpToNextLevel: (data?.xpToNextLevel as number) ?? 100,
    level:         (data?.level as number) ?? 1,
    coins:         (data?.coins as number) ?? 0,
    rank:          (data?.rank as string) ?? 'bronze-rookie',
    badges:        (data?.badges as string[]) ?? [],
    familyId:      data?.familyId as string | undefined,
    role:          (data?.role as UserRole) ?? 'member',
    status:        (data?.status as UserProfile['status']) ?? 'pending',
  }
}

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user,    setUser]    = useState<UserProfile | null>(null)
  const [loading, setLoading] = useState(true)

  // ── Demo mode: restore session from localStorage ──
  useEffect(() => {
    if (isFirebaseConfigured) return
    try {
      const raw = localStorage.getItem(DEMO_SESSION_KEY)
      if (raw) {
        const { role } = JSON.parse(raw) as { role: UserRole }
        setUser(demoProfile(role))
      }
    } catch { /* corrupt session — stay signed out */ }
    setLoading(false)
  }, [])

  // ── Real mode: Firebase auth listener + Firestore profile ──
  useEffect(() => {
    if (!isFirebaseConfigured || !auth) return

    const unsub = onAuthStateChanged(auth, async (fbUser) => {
      if (!fbUser) {
        setUser(null)
        setLoading(false)
        return
      }
      const ref  = doc(db!, 'users', fbUser.uid)
      const snap = await getDoc(ref)
      if (!snap.exists()) {
        // First sign-in: create the profile as Pending Approval (private club).
        const fresh = {
          displayName: fbUser.displayName ?? 'عضو جديد',
          email:       fbUser.email,
          emoji:       '🙂',
          streak: 0, xp: 0, xpToNextLevel: 100, level: 1, coins: 0,
          rank: 'bronze-rookie', badges: [],
          role: 'member', status: 'pending',
          createdAt: serverTimestamp(),
        }
        await setDoc(ref, fresh)
        setUser(profileFromDoc(fbUser.uid, fresh, fbUser))
      } else {
        setUser(profileFromDoc(fbUser.uid, snap.data(), fbUser))
      }
      setLoading(false)
    })
    return unsub
  }, [])

  const signInDemo = useCallback((role: UserRole) => {
    localStorage.setItem(DEMO_SESSION_KEY, JSON.stringify({ role }))
    setUser(demoProfile(role))
  }, [])

  const signInWithGoogle = useCallback(async () => {
    if (!isFirebaseConfigured || !auth) { signInDemo('member'); return }
    await signInWithPopup(auth, new GoogleAuthProvider())
  }, [signInDemo])

  const signInWithEmail = useCallback(async (email: string, password: string) => {
    if (!isFirebaseConfigured || !auth) { signInDemo('member'); return }
    await signInWithEmailAndPassword(auth, email, password)
  }, [signInDemo])

  const signUpWithEmail = useCallback(async (email: string, password: string, displayName: string) => {
    if (!isFirebaseConfigured || !auth) { signInDemo('member'); return }
    const cred = await createUserWithEmailAndPassword(auth, email, password)
    await setDoc(doc(db!, 'users', cred.user.uid), {
      displayName, email,
      emoji: '🙂',
      streak: 0, xp: 0, xpToNextLevel: 100, level: 1, coins: 0,
      rank: 'bronze-rookie', badges: [],
      role: 'member', status: 'pending',
      createdAt: serverTimestamp(),
    })
  }, [signInDemo])

  const resetPassword = useCallback(async (email: string) => {
    if (!isFirebaseConfigured || !auth) return
    await sendPasswordResetEmail(auth, email)
  }, [])

  const signOutUser = useCallback(async () => {
    if (isFirebaseConfigured && auth) await signOut(auth)
    localStorage.removeItem(DEMO_SESSION_KEY)
    setUser(null)
  }, [])

  return (
    <AuthContext.Provider
      value={{
        user, loading,
        demoMode: !isFirebaseConfigured,
        signInWithGoogle, signInWithEmail, signUpWithEmail,
        resetPassword, signOutUser, signInDemo,
      }}
    >
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const ctx = useContext(AuthContext)
  if (!ctx) throw new Error('useAuth must be used inside <AuthProvider>')
  return ctx
}
