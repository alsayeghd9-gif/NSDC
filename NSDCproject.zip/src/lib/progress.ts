import type { UnlockPayload } from './types'
import { mockRanks, mockBadges } from './mockData'

/**
 * Pure game-logic engine for the daily check-in loop.
 * No I/O here — ProgressContext handles persistence (Firestore or localStorage).
 */

export const XP_PER_CHECKIN = 20

/** XP needed to finish the given level (level 4 → 300, matching the designs). */
export const xpThreshold = (level: number) => 75 * level

/** Every 10 levels unlocks a new rank: 1–10 bronze, 11–20 silver, … */
export const rankIndexForLevel = (level: number) =>
  Math.min(Math.floor((level - 1) / 10), mockRanks.length - 1)

export type ProgressState = {
  streak: number
  bestStreak: number
  totalCheckIns: number
  /** XP progress within the current level. */
  xp: number
  level: number
  coins: number
  /** Future feature: a shield forgives one missed day without breaking the streak. */
  streakShields: number
  /** Local date of last check-in, YYYY-MM-DD. */
  lastCheckIn: string | null
  /** badge id → ISO date unlocked */
  badges: Record<string, string>
}

export type CheckInResult = {
  state: ProgressState
  unlocks: UnlockPayload[]
  xpEarned: number
  coinsEarned: number
  leveledUpTo: number | null
  usedShield: boolean
  alreadyCheckedIn: boolean
}

// ── Date helpers (local time — a "day" is the member's own day) ──

export function todayKey(d = new Date()): string {
  const y = d.getFullYear()
  const m = String(d.getMonth() + 1).padStart(2, '0')
  const day = String(d.getDate()).padStart(2, '0')
  return `${y}-${m}-${day}`
}

export function dayDiff(fromKey: string, toKey: string): number {
  const [fy, fm, fd] = fromKey.split('-').map(Number)
  const [ty, tm, td] = toKey.split('-').map(Number)
  const from = Date.UTC(fy, fm - 1, fd)
  const to   = Date.UTC(ty, tm - 1, td)
  return Math.round((to - from) / 86_400_000)
}

/** "2025-01-17" → "17 يناير" (Latin digits, Arabic month — matches the designs). */
export function formatArabicDate(iso: string): string {
  const [y, m, d] = iso.split('-').map(Number)
  return new Intl.DateTimeFormat('ar-u-nu-latn', { day: 'numeric', month: 'long' })
    .format(new Date(y, m - 1, d))
}

// ── Badge unlock conditions ──

const BADGE_MESSAGES: Record<string, string> = {
  'first-checkin': 'سجّلت أول تسجيل لك في النادي. مبروك على هذه الخطوة الأولى الرائعة! 🌟',
  'first-week':    'أتممت 7 أيام متتالية بدون مشروبات غازية. استمر في هذا الأسلوب الرائع 🌟',
  'first-month':   '30 يوماً كاملة بدون مشروبات غازية! إنجاز يستحق الاحتفال 🎉',
  'hundred-days':  '100 يوم! أنت مثال يُحتذى به في النادي 💯',
  'year-champion': 'سنة كاملة! أنت بطل حقيقي وقدوة لكل العائلات 🏆',
  'best-streak':   'هذه أفضل سلسلة لك حتى الآن. احتفظ بهذا الرقم وحاول تجاوزه! 🔥',
  'comeback':      'عدت بقوة بعد انقطاع. العودة أصعب من البداية — أحسنت! 🔄',
}

export function badgeMessage(id: string): string {
  return BADGE_MESSAGES[id] ?? 'مبروك على فتح هذا الوسام! استمر في رحلتك الصحية.'
}

type BadgeCheck = (s: ProgressState, ctx: { cameBack: boolean; newBest: boolean }) => boolean

const BADGE_CONDITIONS: Record<string, BadgeCheck> = {
  'first-checkin': s => s.totalCheckIns >= 1,
  'first-week':    s => s.streak >= 7,
  'first-month':   s => s.streak >= 30,
  'hundred-days':  s => s.streak >= 100,
  'year-champion': s => s.streak >= 365,
  'best-streak':   (s, ctx) => ctx.newBest && s.streak >= 3,
  'comeback':      (_s, ctx) => ctx.cameBack,
}

// ── The check-in transition ──

export function applyCheckIn(prev: ProgressState, today = todayKey()): CheckInResult {
  if (prev.lastCheckIn === today) {
    return {
      state: prev, unlocks: [], xpEarned: 0, coinsEarned: 0,
      leveledUpTo: null, usedShield: false, alreadyCheckedIn: true,
    }
  }

  const gap = prev.lastCheckIn ? dayDiff(prev.lastCheckIn, today) : Infinity

  // Streak: consecutive day extends it; a single missed day can be saved by a
  // Streak Shield (future feature — shields default to 0); otherwise reset to 1.
  let streakShields = prev.streakShields
  let usedShield = false
  let streak: number
  if (gap === 1) {
    streak = prev.streak + 1
  } else if (gap === 2 && streakShields > 0) {
    streakShields -= 1
    usedShield = true
    streak = prev.streak + 1
  } else {
    streak = 1
  }

  const cameBack = gap !== 1 && !usedShield && prev.totalCheckIns > 0
  const totalCheckIns = prev.totalCheckIns + 1
  const newBest = streak > prev.bestStreak
  const bestStreak = Math.max(streak, prev.bestStreak)

  // XP + immediate level-up (rolls over across multiple levels if needed)
  let xp = prev.xp + XP_PER_CHECKIN
  let level = prev.level
  while (xp >= xpThreshold(level)) {
    xp -= xpThreshold(level)
    level += 1
  }
  const leveledUpTo = level > prev.level ? level : null

  // Coins: weekly doubling while the streak stays alive (7→5, 14→10, 21→20, …)
  const coinsEarned = streak > 0 && streak % 7 === 0
    ? 5 * 2 ** (streak / 7 - 1)
    : 0

  const next: ProgressState = {
    streak, bestStreak, totalCheckIns,
    xp, level,
    coins: prev.coins + coinsEarned,
    streakShields,
    lastCheckIn: today,
    badges: { ...prev.badges },
  }

  const unlocks: UnlockPayload[] = []
  const unlockedDate = formatArabicDate(today)

  // Newly earned badges
  for (const badge of mockBadges) {
    if (next.badges[badge.id]) continue
    const condition = BADGE_CONDITIONS[badge.id]
    if (condition && condition(next, { cameBack, newBest })) {
      next.badges[badge.id] = today
      unlocks.push({
        type: 'badge',
        emoji: badge.emoji,
        nameAr: badge.nameAr,
        nameEn: badge.nameEn,
        message: badgeMessage(badge.id),
        unlockedAt: unlockedDate,
      })
    }
  }

  // Rank promotion (every 10 levels)
  const prevRank = rankIndexForLevel(prev.level)
  const newRank  = rankIndexForLevel(level)
  if (newRank > prevRank) {
    const rank = mockRanks[newRank]
    unlocks.push({
      type: 'rank',
      emoji: '🛡️',
      nameAr: rank.nameAr,
      nameEn: rank.nameEn,
      message: `وصلت إلى مرتبة ${rank.nameAr}! مثابرتك تصنع الفرق كل يوم 🏅`,
      unlockedAt: unlockedDate,
    })
  }

  return {
    state: next, unlocks,
    xpEarned: XP_PER_CHECKIN, coinsEarned,
    leveledUpTo, usedShield, alreadyCheckedIn: false,
  }
}

// ── Seeds ──

/** Fresh member (real Firebase mode before any check-in). */
export function emptyProgress(): ProgressState {
  return {
    streak: 0, bestStreak: 0, totalCheckIns: 0,
    xp: 0, level: 1, coins: 0,
    streakShields: 0, lastCheckIn: null, badges: {},
  }
}

/** Demo-mode seed matching the design mocks: 12-day streak, level 4, 3 badges. */
export function demoProgress(): ProgressState {
  const yesterday = new Date()
  yesterday.setDate(yesterday.getDate() - 1)
  return {
    streak: 12, bestStreak: 12, totalCheckIns: 12,
    xp: 240, level: 4, coins: 20,
    streakShields: 0,
    lastCheckIn: todayKey(yesterday),
    badges: {
      'first-checkin': '2025-01-10',
      'first-week':    '2025-01-17',
      'best-streak':   '2025-01-27',
    },
  }
}
