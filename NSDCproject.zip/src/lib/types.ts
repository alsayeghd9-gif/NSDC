export type UserRole = 'member' | 'admin' | 'founder'
export type MemberStatus = 'pending' | 'approved' | 'rejected'
export type EncouragementStatus = 'pending' | 'approved' | 'rejected'
export type MemberBadgeLabel = 'أم' | 'أب' | 'مراهق' | 'مراهقة' | 'طفل' | 'بالغ' | null

export type Rank = {
  id: string
  nameAr: string
  nameEn: string
  requiredLevel: number
  gradient: string
  borderColor: string
}

export type Badge = {
  id: string
  emoji: string
  nameAr: string
  nameEn: string
  requirement: string
  requirementAr: string
  unlockedAt?: string | null
}

export type SeasonalAchievement = {
  id: string
  emoji: string
  nameAr: string
  unlockedAt?: string | null
  requirement?: string
}

export type FamilyAchievement = {
  id: string
  emoji: string
  nameAr: string
  descriptionAr: string
  unlockedAt?: string | null
}

export type Encouragement = {
  id: string
  emoji: string
  text: string
  authorName: string
  badge: MemberBadgeLabel
  status: EncouragementStatus
  createdAt: string
}

export type UserProfile = {
  uid: string
  displayName: string
  email?: string
  emoji: string
  streak: number
  xp: number
  xpToNextLevel: number
  level: number
  coins: number
  rank: string
  badges: string[]
  familyId?: string
  role: UserRole
  status: MemberStatus
  badgeLabel?: MemberBadgeLabel
}

export type LeaderboardEntry = {
  uid: string
  displayName: string
  emoji: string
  level: number
  rankLabelAr: string
  streak: number
}

export type FamilyMember = {
  uid: string
  displayName: string
  emoji: string
  checkedInToday: boolean
}

export type UnlockPayload = {
  type: 'badge' | 'rank' | 'seasonal' | 'family'
  emoji: string
  nameAr: string
  nameEn: string
  message: string
  unlockedAt: string
}
