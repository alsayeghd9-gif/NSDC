import type {
  UserProfile, FamilyMember, Encouragement,
  Badge, Rank, SeasonalAchievement, FamilyAchievement,
} from './types'

export const mockUser: UserProfile = {
  uid: 'mock-uid-ahmed',
  displayName: 'أحمد',
  emoji: '👦',
  streak: 12,
  xp: 240,
  xpToNextLevel: 300,
  level: 4,
  coins: 20,
  rank: 'bronze-rookie',
  badges: ['first-checkin', 'first-week', 'best-streak'],
  role: 'member',
  status: 'approved',
  badgeLabel: null,
}

export const mockFamily: FamilyMember[] = [
  { uid: 'f1', displayName: 'أحمد',  emoji: '👦', checkedInToday: true  },
  { uid: 'f2', displayName: 'الأم',  emoji: '👩', checkedInToday: true  },
  { uid: 'f3', displayName: 'الأب',  emoji: '👨', checkedInToday: false },
  { uid: 'f4', displayName: 'سارة',  emoji: '👧', checkedInToday: false },
]

export const mockEncouragements: Encouragement[] = [
  { id: 'e1', emoji: '💛', text: 'استمر! كل قرار صحي يهم مهما كان صغيراً.',          authorName: 'أحمد',  badge: null,       status: 'approved', createdAt: '2025-01-10' },
  { id: 'e2', emoji: '🌱', text: 'أكملنا كعائلة أسبوعاً كاملاً معاً. شعور لا يُوصف!', authorName: 'فاطمة', badge: 'أم',        status: 'approved', createdAt: '2025-01-12' },
  { id: 'e3', emoji: '⭐', text: 'وصلت إلى 30 يوماً. أنتم تستطيعون أيضاً!',           authorName: 'خالد',  badge: null,       status: 'approved', createdAt: '2025-01-15' },
  { id: 'e4', emoji: '💪', text: 'البداية هي الأصعب. بعدها تصبح عادة جميلة.',          authorName: 'سارة',  badge: 'مراهقة',   status: 'approved', createdAt: '2025-01-18' },
  { id: 'e5', emoji: '🌿', text: 'أطفالي فخورون بي. هذا يكفيني دافعاً كل يوم.',       authorName: 'نورة',  badge: 'أم',        status: 'approved', createdAt: '2025-01-20' },
]

export const mockRanks: Rank[] = [
  { id: 'bronze-rookie',    nameAr: 'البرونزي المبتدئ', nameEn: 'Bronze Rookie',    requiredLevel: 1,  gradient: 'linear-gradient(145deg,#3D1E00,#5C2E00)', borderColor: '#CD7F32' },
  { id: 'silver-challenger',nameAr: 'الفضي المتحدي',    nameEn: 'Silver Challenger', requiredLevel: 11, gradient: 'linear-gradient(145deg,#1E2E40,#2A4060)', borderColor: '#C0C0C0' },
  { id: 'gold-guardian',    nameAr: 'الذهبي الحارس',    nameEn: 'Gold Guardian',     requiredLevel: 21, gradient: 'linear-gradient(145deg,#3D3000,#5C4800)', borderColor: '#FFD700' },
  { id: 'platinum-elite',   nameAr: 'البلاتيني النخبة',  nameEn: 'Platinum Elite',    requiredLevel: 31, gradient: 'linear-gradient(145deg,#1E2E36,#2A4450)', borderColor: '#E5E4E2' },
  { id: 'diamond-legend',   nameAr: 'الماسي الأسطوري',  nameEn: 'Diamond Legend',    requiredLevel: 41, gradient: 'linear-gradient(145deg,#0D1A36,#1A2A58)', borderColor: '#B9F2FF' },
]

export const mockBadges: Badge[] = [
  { id: 'first-checkin', emoji: '🌟', nameAr: 'أول تسجيل',     nameEn: 'First Check-In', requirement: '',             requirementAr: '',          unlockedAt: '10 يناير' },
  { id: 'first-week',    emoji: '📅', nameAr: 'أول أسبوع',     nameEn: 'First Week',     requirement: '7 days',       requirementAr: '',          unlockedAt: '17 يناير' },
  { id: 'best-streak',   emoji: '🔥', nameAr: 'أفضل سلسلة',    nameEn: 'Best Streak',    requirement: '',             requirementAr: '12 يوم ✓',  unlockedAt: '27 يناير' },
  { id: 'first-month',   emoji: '🗓', nameAr: 'أول شهر',       nameEn: 'First Month',    requirement: '30 days',      requirementAr: '30 يوماً',  unlockedAt: null },
  { id: 'hundred-days',  emoji: '💯', nameAr: 'مئة يوم',       nameEn: '100-Day Streak', requirement: '100 days',     requirementAr: '100 يوم',   unlockedAt: null },
  { id: 'year-champion', emoji: '🏆', nameAr: 'بطل السنة',     nameEn: 'One-Year Champion',requirement: '365 days',   requirementAr: '365 يوماً', unlockedAt: null },
  { id: 'comeback',      emoji: '🔄', nameAr: 'عودة قوية',     nameEn: 'Comeback',       requirement: 'after break',  requirementAr: 'بعد انقطاع',unlockedAt: null },
  { id: 'leaderboard',   emoji: '📊', nameAr: 'من المتصدرين',  nameEn: 'Top 10',         requirement: 'top 10',       requirementAr: 'أعلى 10',   unlockedAt: null },
  { id: 'family-champ',  emoji: '👨‍👩‍👧', nameAr: 'إنجاز عائلي', nameEn: 'Family Achievement',requirement: 'family week',requirementAr: 'أسبوع عائلي',unlockedAt: null },
]

export const mockSeasonalAchievements: SeasonalAchievement[] = [
  { id: 's1', emoji: '🌟', nameAr: 'مشارك الموسم 1', unlockedAt: 'يناير 2025' },
  { id: 's2', emoji: '🏅', nameAr: 'أعلى 10 موسم 1', unlockedAt: null, requirement: 'أعلى 10' },
]

export const mockFamilyAchievements: FamilyAchievement[] = [
  { id: 'fa1', emoji: '👨‍👩‍👧', nameAr: 'أول تسجيل عائلي',   descriptionAr: '15 يناير 2025', unlockedAt: '15 يناير 2025' },
  { id: 'fa2', emoji: '📆',    nameAr: 'أسبوع عائلي كامل', descriptionAr: '7 أيام متتالية معاً', unlockedAt: null },
  { id: 'fa3', emoji: '🏆',    nameAr: 'أطول سلسلة عائلية', descriptionAr: 'أطول سلسلة بالعائلة', unlockedAt: null },
]
