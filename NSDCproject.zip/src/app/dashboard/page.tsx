'use client'

import MascotIcon from '@/components/ui/MascotIcon'
import CommunityCard from '@/components/CommunityCard'
import BottomNav from '@/components/ui/BottomNav'
import AuthGuard from '@/components/AuthGuard'
import { useAuth } from '@/context/AuthContext'
import { useProgress } from '@/context/ProgressContext'
import { XP_PER_CHECKIN } from '@/lib/progress'
import { mockUser, mockFamily, mockEncouragements } from '@/lib/mockData'

export default function DashboardPage() {
  return (
    <AuthGuard>
      <DashboardContent />
    </AuthGuard>
  )
}

function DashboardContent() {
  const { user: authUser } = useAuth()
  const { progress, checkedInToday, xpToNext, checkIn } = useProgress()
  const user   = authUser ?? mockUser
  const family = mockFamily
  const msgs   = mockEncouragements.filter(m => m.status === 'approved')

  const streak = progress?.streak ?? 0
  const level  = progress?.level ?? 1
  const xp     = progress?.xp ?? 0
  const xpPct  = Math.min(100, Math.round((xp / xpToNext) * 100))

  return (
    <div
      className="min-h-screen flex flex-col rtl font-cairo"
      style={{ background: '#FFF9F0' }}
      dir="rtl"
    >
      {/* ── Yellow status bar ── */}
      <div
        className="flex items-end justify-between px-[22px] pb-[10px] flex-shrink-0"
        style={{ height: 48, background: '#FFD166' }}
      >
        <span className="text-[14px] font-bold" style={{ color: '#5A4000', direction: 'ltr', fontFamily: 'system-ui,sans-serif' }}>
          9:41
        </span>
        <div className="flex gap-[5px] items-center">
          <svg width="18" height="11" viewBox="0 0 18 11" fill="none">
            <rect x="0" y="4"  width="3" height="7"  rx="1.5" fill="#5A4000"/>
            <rect x="5" y="2"  width="3" height="9"  rx="1.5" fill="#5A4000"/>
            <rect x="10" y="0" width="3" height="11" rx="1.5" fill="#5A4000"/>
            <rect x="15" y="0" width="3" height="11" rx="1.5" fill="#5A4000" opacity=".3"/>
          </svg>
          <svg width="26" height="12" viewBox="0 0 26 12" fill="none">
            <rect x=".5" y=".5" width="21" height="11" rx="2.5" stroke="#5A4000" strokeWidth="1"/>
            <rect x="2" y="2" width="16" height="8" rx="1.5" fill="#5A4000"/>
            <path d="M22.5 4v4M24.5 4.5v3" stroke="#5A4000" strokeWidth="1.5" strokeLinecap="round"/>
          </svg>
        </div>
      </div>

      {/* ── Scrollable content ── */}
      <div className="flex-1 overflow-y-auto no-scrollbar" style={{ WebkitOverflowScrolling: 'touch' }}>

        {/* Hero gradient */}
        <div
          className="px-[22px] pb-[36px] pt-[14px] text-center"
          style={{ background: 'linear-gradient(175deg,#FFD166 0%,#FFDF84 50%,#FFF6D0 76%,#FFF9F0 100%)' }}
        >
          <div className="inline-block mb-[6px]">
            <MascotIcon width={56} height={67} />
          </div>
          <p className="text-[13px] font-semibold mb-[10px]" style={{ color: '#7A5500' }}>
            مرحباً، {user.displayName}! 👋
          </p>
          {/* Streak pill */}
          <div
            className="inline-flex items-center gap-[12px] rounded-[20px] px-[26px] py-[10px]"
            style={{ background: 'rgba(255,255,255,0.62)', boxShadow: '0 4px 18px rgba(0,0,0,0.08)' }}
          >
            <span
              className="font-black leading-none"
              style={{ fontSize: 52, color: '#1A1A1A', letterSpacing: -2 }}
            >
              {streak}
            </span>
            <div className="text-right">
              <div className="text-[22px] leading-none mb-[2px]">🔥</div>
              <div className="text-[14px] font-extrabold leading-[1.2]" style={{ color: '#1A1A1A' }}>يوماً</div>
              <div className="text-[9px] font-semibold mt-[1px]" style={{ color: '#7A5500' }}>بدون غازيات</div>
            </div>
          </div>
        </div>

        {/* ── Check-in card ── */}
        <div className="mx-[14px] -mt-[20px] relative z-[2]">
          <div
            className="rounded-[22px] px-[16px] py-[15px]"
            style={{ background: 'white', boxShadow: '0 8px 30px rgba(0,0,0,0.12)' }}
          >
            <p className="text-center text-[13px] font-bold mb-[3px]" style={{ color: '#1A1A1A' }}>
              هل حافظت على تعهدك اليوم؟
            </p>
            <p className="text-center text-[10px] mb-[13px]" style={{ color: '#C0B5A8' }}>
              Did you keep your pledge today?
            </p>
            {checkedInToday ? (
              <div
                className="rounded-[14px] px-[14px] py-[14px] text-center"
                style={{ background: 'linear-gradient(145deg,#EEF9F4,#D4F5EB)' }}
              >
                <p className="text-[17px] font-black mb-[2px]" style={{ color: '#06D6A0' }}>
                  ✅ تم التسجيل اليوم!
                </p>
                <p className="text-[10px]" style={{ color: '#06D6A0' }}>Check-in recorded · +{XP_PER_CHECKIN} XP</p>
              </div>
            ) : (
              <button
                onClick={checkIn}
                className="w-full rounded-[14px] px-[14px] py-[14px] text-center cursor-pointer"
                style={{
                  background: 'linear-gradient(145deg,#06D6A0,#04BE8C)',
                  boxShadow:  '0 6px 22px rgba(6,214,160,0.38)',
                }}
              >
                <p className="text-[17px] font-black text-white mb-[2px]">
                  نعم، لم اشرب الغازيات اليوم! 💚
                </p>
                <p className="text-[10px]" style={{ color: 'rgba(255,255,255,0.72)' }}>
                  Yes, I kept my pledge!
                </p>
              </button>
            )}
          </div>
        </div>

        {/* ── Community encouragement card ── */}
        <CommunityCard messages={msgs} />

        {/* ── XP progress bar ── */}
        <div
          className="mx-[14px] mt-[10px] px-[14px] py-[13px] rounded-[16px]"
          style={{ background: 'white', boxShadow: '0 2px 10px rgba(0,0,0,0.05)' }}
        >
          <div className="flex justify-between items-center mb-[7px]">
            <span className="text-[12px] font-bold" style={{ color: '#1A1A1A' }}>
              المستوى {level} 🌟
            </span>
            <span className="text-[11px] font-semibold" style={{ color: '#D4920A' }}>
              {xp} / {xpToNext} نقطة
            </span>
          </div>
          <div className="h-[8px] rounded-[8px] overflow-hidden" style={{ background: '#F5EFE4' }}>
            <div
              className="h-full rounded-[8px]"
              style={{ width: `${xpPct}%`, background: 'linear-gradient(90deg,#FFD166,#FFA500)' }}
            />
          </div>
        </div>

        {/* ── Family status ── */}
        <div
          className="mx-[14px] mt-[10px] mb-[18px] p-[14px] rounded-[16px]"
          style={{ background: 'white', boxShadow: '0 2px 10px rgba(0,0,0,0.05)' }}
        >
          <div className="text-[13px] font-bold mb-[12px] flex items-center gap-[6px]" style={{ color: '#1A1A1A' }}>
            <span>العائلة اليوم</span>
            <span className="text-[16px]">👨‍👩‍👧</span>
          </div>
          <div className="flex gap-[10px]">
            {family.map((member, i) => (
              <div
                key={member.uid}
                className="text-center flex-1"
                style={{ opacity: i === 3 ? 0.44 : 1 }}
              >
                <div
                  className="w-[44px] h-[44px] rounded-full flex items-center justify-center text-[22px] mx-auto mb-[5px]"
                  style={{
                    background: i === 0 ? '#FFF4CC' : i === 1 ? '#FFE8E8' : i === 2 ? '#E8F0FF' : '#F5F5F5',
                    border:     `3px solid ${member.checkedInToday ? '#06D6A0' : '#E5E5E5'}`,
                  }}
                >
                  {member.emoji}
                </div>
                <p className="text-[10px] font-bold" style={{ color: member.checkedInToday ? '#1A1A1A' : '#AAA' }}>
                  {member.displayName}
                </p>
                {member.checkedInToday ? (
                  <p className="text-[9px] font-bold" style={{ color: '#06D6A0' }}>
                    ✓ {i === 1 ? 'حافظت' : 'حافظ'}
                  </p>
                ) : (
                  <p className="text-[9px]" style={{ color: i === 3 ? '#DDD' : '#CCC' }}>
                    {i === 3 ? '—' : 'لم يسجّل'}
                  </p>
                )}
              </div>
            ))}
          </div>
        </div>

      </div>

      {/* ── Bottom navigation ── */}
      <BottomNav theme="light" />
    </div>
  )
}
