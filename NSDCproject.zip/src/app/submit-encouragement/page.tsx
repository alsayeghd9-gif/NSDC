'use client'

import { useRouter } from 'next/navigation'
import SubmitEncouragementForm from '@/components/SubmitEncouragementForm'
import AuthGuard from '@/components/AuthGuard'
import { useAuth } from '@/context/AuthContext'
import { mockUser } from '@/lib/mockData'

export default function SubmitEncouragementPage() {
  return (
    <AuthGuard>
      <SubmitEncouragementContent />
    </AuthGuard>
  )
}

function SubmitEncouragementContent() {
  const router = useRouter()
  const { user: authUser } = useAuth()
  const user   = authUser ?? mockUser

  return (
    <div
      className="min-h-screen flex flex-col rtl font-cairo"
      style={{ background: 'white' }}
      dir="rtl"
    >
      {/* ── White status bar ── */}
      <div
        className="flex items-end justify-between px-[22px] pb-[10px] flex-shrink-0"
        style={{ height: 48, background: 'white', borderBottom: '1px solid #F5EFE8' }}
      >
        <span className="text-[14px] font-bold" style={{ color: '#333', direction: 'ltr', fontFamily: 'system-ui,sans-serif' }}>
          9:41
        </span>
        <div className="flex gap-[5px] items-center">
          <svg width="18" height="11" viewBox="0 0 18 11" fill="none">
            <rect x="0" y="4"  width="3" height="7"  rx="1.5" fill="#333"/>
            <rect x="5" y="2"  width="3" height="9"  rx="1.5" fill="#333"/>
            <rect x="10" y="0" width="3" height="11" rx="1.5" fill="#333"/>
            <rect x="15" y="0" width="3" height="11" rx="1.5" fill="#333" opacity=".28"/>
          </svg>
          <svg width="26" height="12" viewBox="0 0 26 12" fill="none">
            <rect x=".5" y=".5" width="21" height="11" rx="2.5" stroke="#333" strokeWidth="1"/>
            <rect x="2" y="2" width="16" height="8" rx="1.5" fill="#333"/>
            <path d="M22.5 4v4M24.5 4.5v3" stroke="#333" strokeWidth="1.5" strokeLinecap="round"/>
          </svg>
        </div>
      </div>

      {/* ── Nav bar ── */}
      <div
        className="h-[52px] flex items-center justify-between px-[20px] flex-shrink-0"
        style={{ borderBottom: '1px solid #F5EFE8' }}
      >
        <button onClick={() => router.back()} className="text-[14px] cursor-pointer" style={{ color: '#C0B5A8' }}>
          إلغاء
        </button>
        <h1 className="text-[16px] font-extrabold" style={{ color: '#1A1A1A' }}>شارك تشجيعك</h1>
        <div className="w-[40px]" />
      </div>

      <SubmitEncouragementForm
        userName={user.displayName}
        userEmoji={user.emoji}
        rankLabel="🥉 البرونزي"
      />
    </div>
  )
}
