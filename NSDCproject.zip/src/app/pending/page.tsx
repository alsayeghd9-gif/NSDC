'use client'

import { useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { useAuth } from '@/context/AuthContext'

export default function PendingApprovalPage() {
  const router = useRouter()
  const { user, loading, signOutUser } = useAuth()

  useEffect(() => {
    if (loading) return
    if (!user) router.replace('/')
    else if (user.status === 'approved') router.replace('/dashboard')
  }, [user, loading, router])

  const handleBack = async () => {
    await signOutUser()
    router.replace('/')
  }

  return (
    <div className="min-h-screen flex flex-col font-cairo" style={{ background: '#FFF9F0' }} dir="rtl">
      <div className="flex-1 flex flex-col items-center justify-center px-[24px] py-[28px] text-center">

        {/* Mascot with waiting clock badge */}
        <div className="relative inline-block mb-[18px]">
          <div className="animate-mascot-bounce" style={{ animationDuration: '2.3s' }}>
            <svg width="86" height="102" viewBox="0 0 74 88" xmlns="http://www.w3.org/2000/svg">
              <path d="M37 5C37 5 9 46 9 62C9 76.5 21.5 86 37 86C52.5 86 65 76.5 65 62C65 46 37 5 37 5Z" fill="#FFD166"/>
              <path d="M25 20C20 33 13 48 12 60" stroke="rgba(255,255,255,0.44)" strokeWidth="6.5" strokeLinecap="round" fill="none"/>
              <ellipse cx="15" cy="66" rx="8.5" ry="5.5" fill="#CC8000" opacity=".26"/>
              <ellipse cx="59" cy="66" rx="8.5" ry="5.5" fill="#CC8000" opacity=".26"/>
              {/* side-glancing eyes */}
              <ellipse cx="27" cy="57" rx="7" ry="7.5" fill="#1A1A1A"/>
              <ellipse cx="47" cy="57" rx="7" ry="7.5" fill="#1A1A1A"/>
              <circle cx="31" cy="53" r="3" fill="white"/>
              <circle cx="51" cy="53" r="3" fill="white"/>
              <path d="M26 69Q37 77 48 69" stroke="#1A1A1A" strokeWidth="2.5" strokeLinecap="round" fill="none"/>
              <ellipse cx="37" cy="86" rx="18" ry="3" fill="rgba(0,0,0,0.09)"/>
            </svg>
          </div>
          <div
            className="absolute -top-[10px] -right-[14px] w-[38px] h-[38px] rounded-full flex items-center justify-center text-[20px]"
            style={{ background: '#FFD166', boxShadow: '0 4px 14px rgba(0,0,0,0.14)', border: '3px solid white' }}
          >
            ⏳
          </div>
        </div>

        {/* Success chip */}
        <div
          className="inline-flex items-center gap-[6px] rounded-[10px] px-[14px] py-[5px] mb-[14px]"
          style={{ background: '#EEF9F4' }}
        >
          <span className="text-[14px]">✓</span>
          <span className="text-[12px] font-bold" style={{ color: '#06D6A0' }}>تم إرسال طلبك بنجاح</span>
        </div>

        <h1 className="text-[28px] font-black leading-[1.2] mb-[6px]" style={{ color: '#1A1A1A' }}>
          طلبك قيد المراجعة
        </h1>
        <p className="text-[13px] font-semibold mb-[24px]" style={{ color: '#AAA' }}>
          Your request is pending review
        </p>

        {/* Info card */}
        <div
          className="w-full max-w-[342px] rounded-[22px] px-[18px] py-[20px] mb-[16px] text-right"
          style={{ background: 'white', boxShadow: '0 4px 18px rgba(0,0,0,0.07)' }}
        >
          <p className="text-[13px] leading-[1.8] mb-[8px]" style={{ color: '#555' }}>
            هذا النادي خاص. سيقوم المؤسس بمراجعة طلبك والموافقة عليه قريباً 💚
          </p>
          <p className="text-[11px] leading-[1.6]" style={{ color: '#C0B5A8' }}>
            This is a private club. The founder will review your request and approve it soon.
          </p>
        </div>

        {/* Email notification chip */}
        <div
          className="w-full max-w-[342px] rounded-[14px] px-[18px] py-[14px] mb-[24px] flex items-center gap-[12px]"
          style={{ background: '#F2FBF7', border: '1.5px solid rgba(6,214,160,0.2)' }}
        >
          <span className="text-[22px]">📬</span>
          <div className="text-right">
            <p className="text-[10px] font-bold mb-[3px]" style={{ color: '#06D6A0' }}>
              سنُخبرك عبر البريد الإلكتروني
            </p>
            <p className="text-[13px]" style={{ color: '#1A1A1A', direction: 'ltr', fontFamily: 'system-ui,sans-serif' }}>
              {user?.email ?? 'ahmed@example.com'}
            </p>
          </div>
        </div>

        <button onClick={handleBack} className="text-[12px] cursor-pointer" style={{ color: '#C0B5A8' }}>
          رجوع إلى تسجيل الدخول ›
        </button>

      </div>
    </div>
  )
}
