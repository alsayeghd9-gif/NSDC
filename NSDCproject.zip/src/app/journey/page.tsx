'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import BottomNav from '@/components/ui/BottomNav'
import ShieldIcon from '@/components/ui/ShieldIcon'
import UnlockCelebration from '@/components/UnlockCelebration'
import AuthGuard from '@/components/AuthGuard'
import { useProgress } from '@/context/ProgressContext'
import { badgeMessage, formatArabicDate, rankIndexForLevel } from '@/lib/progress'
import { mockBadges, mockRanks, mockSeasonalAchievements, mockFamilyAchievements } from '@/lib/mockData'
import type { UnlockPayload } from '@/lib/types'

const LOCKED_RANK_OPACITIES = [0.5, 0.36, 0.25, 0.16]

export default function JourneyPage() {
  return (
    <AuthGuard>
      <JourneyContent />
    </AuthGuard>
  )
}

function JourneyContent() {
  const router = useRouter()
  const { progress } = useProgress()
  const [celebration, setCelebration] = useState<UnlockPayload | null>(null)

  // Live state — updates instantly after a check-in, no reload needed.
  const unlockedBadges = progress?.badges ?? {}
  const activeRankIdx  = rankIndexForLevel(progress?.level ?? 1)

  const handleBadgeClick = (badgeId: string) => {
    const badge = mockBadges.find(b => b.id === badgeId)
    const unlockedIso = unlockedBadges[badgeId]
    if (!badge || !unlockedIso) return
    setCelebration({
      type:       'badge',
      emoji:      badge.emoji,
      nameAr:     badge.nameAr,
      nameEn:     badge.nameEn,
      message:    badgeMessage(badge.id),
      unlockedAt: formatArabicDate(unlockedIso),
    })
  }

  return (
    <>
      {celebration && (
        <UnlockCelebration payload={celebration} onClose={() => setCelebration(null)} />
      )}

      <div
        className="min-h-screen flex flex-col rtl font-cairo"
        style={{ background: '#141414' }}
        dir="rtl"
      >
        {/* ── Dark status bar ── */}
        <div
          className="flex items-end justify-between px-[22px] pb-[10px] flex-shrink-0"
          style={{ height: 48, background: '#141414' }}
        >
          <span className="text-[14px] font-bold" style={{ color: '#555', direction: 'ltr', fontFamily: 'system-ui,sans-serif' }}>
            9:41
          </span>
          <div className="flex gap-[5px] items-center">
            <svg width="18" height="11" viewBox="0 0 18 11" fill="none">
              <rect x="0" y="4"  width="3" height="7"  rx="1.5" fill="#555"/>
              <rect x="5" y="2"  width="3" height="9"  rx="1.5" fill="#555"/>
              <rect x="10" y="0" width="3" height="11" rx="1.5" fill="#555"/>
            </svg>
            <svg width="26" height="12" viewBox="0 0 26 12" fill="none">
              <rect x=".5" y=".5" width="21" height="11" rx="2.5" stroke="#555" strokeWidth="1"/>
              <rect x="2" y="2" width="16" height="8" rx="1.5" fill="#555"/>
              <path d="M22.5 4v4M24.5 4.5v3" stroke="#555" strokeWidth="1.5" strokeLinecap="round"/>
            </svg>
          </div>
        </div>

        {/* ── Header ── */}
        <div
          className="px-[20px] pt-[8px] pb-[16px] flex items-center justify-between flex-shrink-0"
          style={{ background: '#141414', borderBottom: '1px solid #1E1E1E' }}
        >
          <button onClick={() => router.back()} className="text-[14px] cursor-pointer" style={{ color: '#444' }}>
            رجوع ›
          </button>
          <div className="text-center">
            <p className="text-[20px] font-black text-white">رحلتي 🗺</p>
            <p className="text-[10px] mt-[1px]" style={{ color: '#444' }}>My Journey</p>
          </div>
          <div className="w-[48px]" />
        </div>

        {/* ── Scrollable album ── */}
        <div className="flex-1 overflow-y-auto no-scrollbar" style={{ WebkitOverflowScrolling: 'touch' }}>

          {/* RANKS */}
          <div className="px-[14px] pt-[16px]">
            <p className="text-[10px] font-bold tracking-[0.08em] mb-[10px]" style={{ color: '#444' }}>
              المراتب · RANKS
            </p>
            <div className="flex gap-[10px] overflow-x-auto no-scrollbar pb-[6px]">
              {mockRanks.map((rank, i) => {
                const isActive   = i === activeRankIdx
                const isEarned   = i < activeRankIdx
                const lockedDist = i - activeRankIdx
                return (
                  <div
                    key={rank.id}
                    className={`min-w-[78px] rounded-[16px] p-[12px] px-[8px] text-center flex-shrink-0 ${isActive ? 'animate-shimmer-bronze' : ''}`}
                    style={{
                      background:  isActive || isEarned ? 'linear-gradient(145deg,#3D1E00,#5C2E00)' : '#1E1E1E',
                      border:      isActive || isEarned ? `2px solid ${rank.borderColor}` : '1.5px solid #252525',
                      opacity:     isActive || isEarned ? 1 : LOCKED_RANK_OPACITIES[Math.min(lockedDist - 1, 3)],
                    }}
                  >
                    <ShieldIcon locked={!(isActive || isEarned)} fill={isActive || isEarned ? '#F0A060' : '#2E2E2E'} />
                    <p
                      className="text-[8px] font-extrabold mt-[6px] leading-[1.4]"
                      style={{ color: isActive || isEarned ? '#FFD4A0' : '#444' }}
                    >
                      {rank.nameAr.includes(' ') ? (
                        <>
                          {rank.nameAr.split(' ')[0]}<br />{rank.nameAr.split(' ')[1]}
                        </>
                      ) : rank.nameAr}
                    </p>
                    <p className="text-[7px] mt-[2px]" style={{ color: isActive || isEarned ? '#CD7F32' : '#333' }}>
                      {isActive ? '✓ حالياً' : isEarned ? '✓ مكتملة' : `المستوى ${rank.requiredLevel}`}
                    </p>
                  </div>
                )
              })}
            </div>
          </div>

          {/* BADGES */}
          <div className="px-[14px] pt-[16px]">
            <p className="text-[10px] font-bold tracking-[0.08em] mb-[10px]" style={{ color: '#444' }}>
              الأوسمة · BADGES
            </p>
            <div className="grid grid-cols-3 gap-[8px]">
              {mockBadges.map(badge => {
                const unlockedIso = unlockedBadges[badge.id]
                const unlocked    = Boolean(unlockedIso)
                return (
                  <button
                    key={badge.id}
                    onClick={() => unlocked && handleBadgeClick(badge.id)}
                    className="rounded-[14px] px-[8px] py-[11px] text-center transition-transform active:scale-95"
                    style={{
                      background: unlocked ? '#1E1800' : '#1C1C1C',
                      border:     unlocked ? '1.5px solid #382800' : '1px solid #222',
                      boxShadow:  unlocked ? '0 4px 14px rgba(255,200,0,0.1)' : 'none',
                      opacity:    unlocked ? 1 : getLockedOpacity(badge.id),
                      cursor:     unlocked ? 'pointer' : 'default',
                    }}
                  >
                    <div className="text-[28px] mb-[5px]" style={{ filter: unlocked ? 'none' : 'grayscale(1)' }}>
                      {badge.emoji}
                    </div>
                    <p
                      className="text-[9px] font-bold leading-[1.4] mb-[4px]"
                      style={{ color: unlocked ? '#FFD4A0' : '#444' }}
                    >
                      {badge.nameAr}
                    </p>
                    <p className="text-[8px] font-semibold" style={{ color: unlocked ? '#8A6030' : '#333' }}>
                      {unlocked ? `✓ ${formatArabicDate(unlockedIso!)}` : `${badge.requirementAr} 🔒`}
                    </p>
                  </button>
                )
              })}
            </div>
          </div>

          {/* SEASONAL */}
          <div className="px-[14px] pt-[16px]">
            <p className="text-[10px] font-bold tracking-[0.08em] mb-[10px]" style={{ color: '#444' }}>
              موسمية · SEASONAL
            </p>
            <div className="flex gap-[8px]">
              {mockSeasonalAchievements.map(s => {
                const unlocked = !!s.unlockedAt
                return (
                  <div
                    key={s.id}
                    className="flex-1 rounded-[14px] p-[12px] flex items-center gap-[10px]"
                    style={{
                      background: unlocked ? '#1C1A0E' : '#1A1A1A',
                      border:     unlocked ? '1.5px solid #2E2800' : '1px solid #222',
                      opacity:    unlocked ? 1 : 0.38,
                    }}
                  >
                    <span className="text-[24px]" style={{ filter: unlocked ? 'none' : 'grayscale(1)' }}>
                      {s.emoji}
                    </span>
                    <div>
                      <p
                        className="text-[10px] font-bold leading-[1.35] mb-[2px]"
                        style={{ color: unlocked ? '#FFD4A0' : '#3C3C3C' }}
                      >
                        {s.nameAr}
                      </p>
                      <p className="text-[8px] font-semibold" style={{ color: unlocked ? '#8A6030' : '#2E2E2E' }}>
                        {unlocked ? `✓ ${s.unlockedAt}` : `${s.requirement} 🔒`}
                      </p>
                    </div>
                  </div>
                )
              })}
            </div>
          </div>

          {/* FAMILY ACHIEVEMENTS */}
          <div className="px-[14px] pt-[16px] pb-[28px]">
            <p className="text-[10px] font-bold tracking-[0.08em] mb-[10px]" style={{ color: '#444' }}>
              إنجازات العائلة · FAMILY
            </p>
            <div className="flex flex-col gap-[8px]">
              {mockFamilyAchievements.map(fa => {
                const unlocked = !!fa.unlockedAt
                return (
                  <div
                    key={fa.id}
                    className="rounded-[14px] px-[14px] py-[13px] flex items-center gap-[12px]"
                    style={{
                      background: unlocked ? '#0E1C18' : '#1A1A1A',
                      border:     unlocked ? '1.5px solid #143020' : '1px solid #222',
                      opacity:    unlocked ? 1 : getFamilyOpacity(fa.id),
                    }}
                  >
                    <span className="text-[24px]" style={{ filter: unlocked ? 'none' : 'grayscale(1)' }}>
                      {fa.emoji}
                    </span>
                    <div className="flex-1">
                      <p
                        className="text-[11px] font-bold mb-[2px]"
                        style={{ color: unlocked ? '#8CFFD4' : '#3C3C3C' }}
                      >
                        {fa.nameAr}
                      </p>
                      <p className="text-[9px] font-semibold" style={{ color: unlocked ? '#3A8060' : '#2C2C2C' }}>
                        {unlocked ? `✓ ${fa.unlockedAt}` : `${fa.descriptionAr} 🔒`}
                      </p>
                    </div>
                    <span className="text-[13px]" style={{ color: unlocked ? undefined : '#333' }}>
                      {unlocked ? '✅' : '🔒'}
                    </span>
                  </div>
                )
              })}
            </div>
          </div>

        </div>

        {/* ── Bottom nav (ملفي active) ── */}
        <BottomNav theme="dark" />
      </div>
    </>
  )
}

function getLockedOpacity(id: string): number {
  const map: Record<string, number> = {
    'first-month':   0.52,
    'hundred-days':  0.4,
    'year-champion': 0.3,
    'comeback':      0.38,
    'leaderboard':   0.28,
    'family-champ':  0.24,
  }
  return map[id] ?? 0.4
}

function getFamilyOpacity(id: string): number {
  const map: Record<string, number> = { fa1: 1, fa2: 0.42, fa3: 0.28 }
  return map[id] ?? 0.4
}
