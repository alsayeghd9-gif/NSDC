import type { Metadata } from 'next'
import { Cairo } from 'next/font/google'
import { AuthProvider } from '@/context/AuthContext'
import { ProgressProvider } from '@/context/ProgressContext'
import './globals.css'

const cairo = Cairo({
  subsets:  ['arabic', 'latin'],
  weight:   ['400', '600', '700', '900'],
  variable: '--font-cairo',
  display:  'swap',
})

export const metadata: Metadata = {
  title: 'نادي اللا غازيات | No Soft Drinks Club',
  description: 'Transform healthy habits into an enjoyable daily experience',
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ar" dir="rtl" className={cairo.variable}>
      <body className="font-cairo bg-dark-deeper min-h-screen">
        <AuthProvider>
          <ProgressProvider>{children}</ProgressProvider>
        </AuthProvider>
      </body>
    </html>
  )
}
