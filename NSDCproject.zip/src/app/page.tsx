'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { useAuth } from '@/context/AuthContext'

export default function SignInPage() {
  const router = useRouter()
  const {
    user, loading, demoMode,
    signInWithGoogle, signInWithEmail, signUpWithEmail, resetPassword, signInDemo,
  } = useAuth()

  const [mode,     setMode]     = useState<'signin' | 'signup'>('signin')
  const [name,     setName]     = useState('')
  const [email,    setEmail]    = useState('')
  const [password, setPassword] = useState('')
  const [error,    setError]    = useState<string | null>(null)
  const [busy,     setBusy]     = useState(false)
  const [resetSent, setResetSent] = useState(false)

  // Already signed in → route by status
  useEffect(() => {
    if (loading || !user) return
    router.replace(user.status === 'approved' ? '/dashboard' : '/pending')
  }, [user, loading, router])

  const run = async (fn: () => Promise<void>) => {
    setError(null)
    setBusy(true)
    try {
      await fn()
    } catch (e) {
      setError(friendlyError(e))
    } finally {
      setBusy(false)
    }
  }

  const handleEmailSubmit = () => {
    if (!email.trim() || !password) {
      setError('يرجى إدخال البريد الإلكتروني وكلمة المرور')
      return
    }
    if (mode === 'signup' && !name.trim()) {
      setError('يرجى إدخال اسمك')
      return
    }
    run(() =>
      mode === 'signin'
        ? signInWithEmail(email.trim(), password)
        : signUpWithEmail(email.trim(), password, name.trim()),
    )
  }

  const handleForgot = () => {
    if (!email.trim()) {
      setError('أدخل بريدك الإلكتروني أولاً ثم اضغط "نسيت كلمة المرور"')
      return
    }
    run(async () => {
      await resetPassword(email.trim())
      setResetSent(true)
    })
  }

  return (
    <div
      className="min-h-screen flex flex-col font-cairo"
      style={{ background: 'linear-gradient(180deg,#FFD166 0%,#FFEDA0 44%,#FFF9F0 80%)' }}
      dir="rtl"
    >
      <div className="flex-1 overflow-y-auto no-scrollbar px-[24px] pt-[52px] pb-[30px] flex flex-col items-center text-center">

        {/* Bouncing mascot */}
        <div
          className="inline-block mb-[8px] animate-mascot-bounce"
          style={{ filter: 'drop-shadow(0 10px 22px rgba(160,100,0,0.24))' }}
        >
          <svg width="86" height="102" viewBox="0 0 74 88" xmlns="http://www.w3.org/2000/svg">
            <path d="M37 5C37 5 9 46 9 62C9 76.5 21.5 86 37 86C52.5 86 65 76.5 65 62C65 46 37 5 37 5Z" fill="#FFD166"/>
            <path d="M25 20C20 33 13 48 12 60" stroke="rgba(255,255,255,0.44)" strokeWidth="6.5" strokeLinecap="round" fill="none"/>
            <ellipse cx="15" cy="66" rx="8.5" ry="5.5" fill="#CC8000" opacity=".26"/>
            <ellipse cx="59" cy="66" rx="8.5" ry="5.5" fill="#CC8000" opacity=".26"/>
            <ellipse cx="27" cy="59" rx="6.5" ry="7.5" fill="#1A1A1A"/>
            <ellipse cx="47" cy="59" rx="6.5" ry="7.5" fill="#1A1A1A"/>
            <circle cx="29.5" cy="55" r="2.8" fill="white"/>
            <circle cx="49.5" cy="55" r="2.8" fill="white"/>
            <path d="M24 71Q37 82 50 71" stroke="#1A1A1A" strokeWidth="2.8" strokeLinecap="round" fill="none"/>
            <ellipse cx="37" cy="86" rx="18" ry="3" fill="rgba(0,0,0,0.09)"/>
          </svg>
        </div>

        {/* Club name */}
        <h1
          className="text-[27px] font-black leading-[1.15] mb-[3px] animate-fade-up"
          style={{ color: '#1A1A1A', '--delay': '0.3s' } as React.CSSProperties}
        >
          نادي اللا غازيات
        </h1>
        <p
          className="text-[12px] font-semibold tracking-[0.04em] mb-[5px] animate-fade-up"
          style={{ color: '#9A7020', '--delay': '0.42s' } as React.CSSProperties}
        >
          No Soft Drinks Club
        </p>
        <div
          className="flex items-center gap-[8px] mb-[22px] animate-fade-up"
          style={{ '--delay': '0.54s' } as React.CSSProperties}
        >
          <div className="w-[20px] h-px" style={{ background: '#D4B060' }} />
          <span className="text-[10px]" style={{ color: '#B89040' }}>نادٍ خاص · Private Club</span>
          <div className="w-[20px] h-px" style={{ background: '#D4B060' }} />
        </div>

        {/* Google sign-in */}
        <button
          onClick={() => run(signInWithGoogle)}
          disabled={busy}
          className="w-full max-w-[286px] rounded-[8px] px-[16px] py-[12px] flex items-center justify-center gap-[10px] cursor-pointer mb-[14px] animate-fade-up disabled:opacity-60"
          style={{
            background: 'white',
            border:     '1.5px solid #DADCE0',
            boxShadow:  '0 2px 8px rgba(0,0,0,0.07)',
            '--delay':  '0.66s',
          } as React.CSSProperties}
        >
          <svg width="18" height="18" viewBox="0 0 18 18" xmlns="http://www.w3.org/2000/svg">
            <path d="M17.64 9.2c0-.637-.057-1.251-.164-1.84H9v3.481h4.844c-.209 1.125-.843 2.078-1.796 2.717v2.258h2.908c1.702-1.567 2.684-3.875 2.684-6.615z" fill="#4285F4"/>
            <path d="M9 18c2.43 0 4.467-.806 5.956-2.18l-2.908-2.259c-.806.54-1.837.86-3.048.86-2.344 0-4.328-1.584-5.036-3.711H.957v2.332C2.438 15.983 5.482 18 9 18z" fill="#34A853"/>
            <path d="M3.964 10.71c-.18-.54-.282-1.117-.282-1.71s.102-1.17.282-1.71V4.958H.957C.347 6.173 0 7.548 0 9s.348 2.827.957 4.042l3.007-2.332z" fill="#FBBC05"/>
            <path d="M9 3.58c1.321 0 2.508.454 3.44 1.345l2.582-2.58C13.463.891 11.426 0 9 0 5.482 0 2.438 2.017.957 4.958L3.964 7.29C4.672 5.163 6.656 3.58 9 3.58z" fill="#EA4335"/>
          </svg>
          <span className="text-[14px] font-semibold" style={{ color: '#3C4043' }}>
            الدخول بحساب Google
          </span>
        </button>

        {/* Divider */}
        <div
          className="flex items-center gap-[10px] w-full max-w-[286px] mb-[14px] animate-fade-up"
          style={{ '--delay': '0.76s' } as React.CSSProperties}
        >
          <div className="flex-1 h-px" style={{ background: '#E8E0D0' }} />
          <span className="text-[12px]" style={{ color: '#C0B5A8' }}>أو</span>
          <div className="flex-1 h-px" style={{ background: '#E8E0D0' }} />
        </div>

        {/* Name (sign-up only) */}
        {mode === 'signup' && (
          <label
            className="block w-full max-w-[286px] rounded-[12px] px-[16px] py-[12px] mb-[10px] text-right cursor-text"
            style={{ background: 'white', border: '1.5px solid #E8E0D0' }}
          >
            <span className="block text-[10px] mb-[3px]" style={{ color: '#C0B5A8' }}>اسمك</span>
            <input
              type="text"
              value={name}
              onChange={e => setName(e.target.value)}
              placeholder="أحمد"
              className="w-full text-[14px] outline-none bg-transparent"
              style={{ color: '#1A1A1A' }}
            />
          </label>
        )}

        {/* Email */}
        <label
          className="block w-full max-w-[286px] rounded-[12px] px-[16px] py-[12px] mb-[10px] text-right cursor-text animate-fade-up"
          style={{ background: 'white', border: '1.5px solid #E8E0D0', '--delay': '0.84s' } as React.CSSProperties}
        >
          <span className="block text-[10px] mb-[3px]" style={{ color: '#C0B5A8' }}>البريد الإلكتروني</span>
          <input
            type="email"
            value={email}
            onChange={e => setEmail(e.target.value)}
            placeholder="ahmed@example.com"
            className="w-full text-[14px] outline-none bg-transparent text-left"
            style={{ color: '#1A1A1A', direction: 'ltr', fontFamily: 'system-ui,sans-serif' }}
          />
        </label>

        {/* Password */}
        <label
          className="block w-full max-w-[286px] rounded-[12px] px-[16px] py-[12px] mb-[20px] text-right cursor-text animate-fade-up"
          style={{ background: 'white', border: '1.5px solid #E8E0D0', '--delay': '0.92s' } as React.CSSProperties}
        >
          <span className="block text-[10px] mb-[3px]" style={{ color: '#C0B5A8' }}>كلمة المرور</span>
          <input
            type="password"
            value={password}
            onChange={e => setPassword(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && handleEmailSubmit()}
            placeholder="••••••••"
            className="w-full text-[15px] outline-none bg-transparent text-left"
            style={{ color: '#1A1A1A', direction: 'ltr', letterSpacing: 5 }}
          />
        </label>

        {/* Error / info */}
        {error && (
          <p className="w-full max-w-[286px] text-[12px] font-semibold mb-[12px] rounded-[10px] px-3 py-2"
             style={{ color: '#C0392B', background: '#FDECEA' }}>
            {error}
          </p>
        )}
        {resetSent && (
          <p className="w-full max-w-[286px] text-[12px] font-semibold mb-[12px] rounded-[10px] px-3 py-2"
             style={{ color: '#06D6A0', background: '#EEF9F4' }}>
            ✓ أرسلنا رابط إعادة تعيين كلمة المرور إلى بريدك
          </p>
        )}

        {/* CTA */}
        <button
          onClick={handleEmailSubmit}
          disabled={busy}
          className="w-full max-w-[286px] rounded-[14px] py-[16px] text-center cursor-pointer mb-[16px] animate-fade-up disabled:opacity-60"
          style={{
            background: 'linear-gradient(145deg,#06D6A0,#04BE8C)',
            boxShadow:  '0 8px 26px rgba(6,214,160,0.4)',
            '--delay':  '1s',
          } as React.CSSProperties}
        >
          <span className="block text-[17px] font-black text-white mb-[2px]">
            {mode === 'signin' ? 'تسجيل الدخول' : 'إنشاء حساب'}
          </span>
          <span className="block text-[10px]" style={{ color: 'rgba(255,255,255,0.72)' }}>
            {mode === 'signin' ? 'Sign In' : 'Create Account'}
          </span>
        </button>

        {/* Links */}
        <div
          className="flex flex-col gap-[8px] animate-fade-up"
          style={{ '--delay': '1.08s' } as React.CSSProperties}
        >
          {mode === 'signin' && (
            <button onClick={handleForgot} className="text-[12px] cursor-pointer" style={{ color: '#9A7020' }}>
              نسيت كلمة المرور؟ · Forgot Password?
            </button>
          )}
          <button
            onClick={() => { setMode(m => m === 'signin' ? 'signup' : 'signin'); setError(null) }}
            className="text-[12px] font-bold cursor-pointer"
            style={{ color: '#06A57C' }}
          >
            {mode === 'signin' ? 'عضو جديد؟ إنشاء حساب ›' : 'لديك حساب؟ تسجيل الدخول ›'}
          </button>
        </div>

        {/* Demo mode shortcuts — only shown before Firebase is configured */}
        {demoMode && (
          <div className="mt-[26px] w-full max-w-[286px]">
            <div className="flex items-center gap-[10px] mb-[10px]">
              <div className="flex-1 h-px" style={{ background: '#E8E0D0' }} />
              <span className="text-[10px]" style={{ color: '#C0B5A8' }}>وضع تجريبي · Demo (no Firebase yet)</span>
              <div className="flex-1 h-px" style={{ background: '#E8E0D0' }} />
            </div>
            <div className="flex gap-[8px]">
              <button
                onClick={() => signInDemo('member')}
                className="flex-1 rounded-[10px] py-[9px] text-[12px] font-bold cursor-pointer"
                style={{ background: 'white', border: '1.5px solid #E8E0D0', color: '#7A5500' }}
              >
                👦 دخول كعضو
              </button>
              <button
                onClick={() => signInDemo('founder')}
                className="flex-1 rounded-[10px] py-[9px] text-[12px] font-bold cursor-pointer"
                style={{ background: 'white', border: '1.5px solid #E8E0D0', color: '#7A5500' }}
              >
                🛡️ دخول كمؤسس
              </button>
            </div>
          </div>
        )}

      </div>
    </div>
  )
}

function friendlyError(e: unknown): string {
  const code = (e as { code?: string })?.code ?? ''
  const map: Record<string, string> = {
    'auth/invalid-credential':     'البريد الإلكتروني أو كلمة المرور غير صحيحة',
    'auth/user-not-found':         'لا يوجد حساب بهذا البريد الإلكتروني',
    'auth/wrong-password':         'كلمة المرور غير صحيحة',
    'auth/email-already-in-use':   'هذا البريد الإلكتروني مسجّل بالفعل',
    'auth/weak-password':          'كلمة المرور ضعيفة — 6 أحرف على الأقل',
    'auth/invalid-email':          'البريد الإلكتروني غير صالح',
    'auth/popup-closed-by-user':   'أُغلقت نافذة Google قبل إتمام الدخول',
  }
  return map[code] ?? 'حدث خطأ. حاول مرة أخرى'
}
